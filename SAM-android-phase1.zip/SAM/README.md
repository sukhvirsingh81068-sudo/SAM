# SAM — Phase 1 (Core)
Open in Android Studio (Koala+), sync (generates the Gradle wrapper), run on a real phone (mic needs one).

## IMPLEMENTED
- Compose UI: animated orb (idle/listening/thinking/executing/speaking/error), chat, mic + text input
- Voice in (SpeechRecognizer, hi-IN) and out (TextToSpeech, Hindi/English)
- Tool architecture: ToolResult statuses + ToolRegistry (brain never touches Android)
- Tools: open_app, set_timer, set_alarm (system Clock app), battery, time, device info, open_settings, web search (browser)
- Multi-step commands ("... aur ...", ","); report shows ✓/✗ only from real tool results
- Wi-Fi/Bluetooth on/off returns ANDROID_RESTRICTION and opens settings (Android 10+ blocks direct toggle)

## REQUIRES ANDROID/API INTEGRATION (Phase 2-3)
- LLM Brain: implement `Brain` against your own secure backend (never ship API keys in the APK)
- Foreground service + wake word (e.g. Porcupine); lock-screen via assistant role (VoiceInteractionService)
- Volume, DND (notification-policy access), brightness (WRITE_SETTINGS), calls, SMS, calendar, weather

## FUTURE
- Memory, routines/automation, smart home, 22-language support, provider switching

Notes: RuleBasedBrain is a simple offline parser, not real AI understanding. "kal" vs "aaj" for alarms isn't distinguished (Clock app sets next occurrence). Not compiled here (no network in sandbox), so expect minor fixes on first sync.
