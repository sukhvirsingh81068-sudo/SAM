package com.sam.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import com.sam.assistant.core.*
import java.text.SimpleDateFormat
import java.util.*

private fun Context.launch(i: Intent): Boolean {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (i.resolveActivity(packageManager) == null) return false
    startActivity(i); return true
}

class OpenAppTool(private val c: Context) : Tool {
    override val name = "open_app"
    private val aliases = mapOf("youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome", "maps" to "com.google.android.apps.maps")
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val q = args["app"]?.lowercase()?.trim() ?: return ToolResult(Status.FAILED, "Kaunsa app?")
        val pm = c.packageManager
        val pkg = aliases[q]?.takeIf { pm.getLaunchIntentForPackage(it) != null } ?: run {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(main, 0).firstOrNull {
                it.loadLabel(pm).toString().lowercase().contains(q)
            }?.activityInfo?.packageName
        } ?: return ToolResult(Status.APP_NOT_INSTALLED, "$q app mujhe mila nahi")
        val i = pm.getLaunchIntentForPackage(pkg) ?: return ToolResult(Status.FAILED, "$q open nahi ho paya")
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "$q open hai") else ToolResult(Status.FAILED, "$q open nahi ho paya")
    }
}

class SetTimerTool(private val c: Context) : Tool {
    override val name = "set_timer"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val s = args["seconds"]?.toIntOrNull() ?: return ToolResult(Status.FAILED, "Kitne minute ka timer?")
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "${s / 60} minute ka timer chal raha hai")
        else ToolResult(Status.NOT_SUPPORTED, "Clock app timer request accept nahi kar raha")
    }
}

class SetAlarmTool(private val c: Context) : Tool {
    override val name = "set_alarm"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val h = args["hour"]?.toIntOrNull(); val m = args["minute"]?.toIntOrNull() ?: 0
        if (h == null) return ToolResult(Status.FAILED, "Kitne baje ka alarm?")
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "%d:%02d ka alarm set hai".format(h, m))
        else ToolResult(Status.NOT_SUPPORTED, "Clock app alarm request accept nahi kar raha")
    }
}

class BatteryTool(private val c: Context) : Tool {
    override val name = "get_battery_status"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val chg = if (bm.isCharging) ", charging chal rahi hai" else ""
        return ToolResult(Status.SUCCESS, "Battery $pct% hai$chg")
    }
}

class TimeTool : Tool {
    override val name = "get_time"
    override suspend fun execute(args: Map<String, String>) =
        ToolResult(Status.SUCCESS, SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + " baje hain")
}

class DeviceInfoTool : Tool {
    override val name = "get_device_info"
    override suspend fun execute(args: Map<String, String>) =
        ToolResult(Status.SUCCESS, "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
}

class OpenSettingsTool(private val c: Context) : Tool {
    override val name = "open_settings"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val action = when (args["section"]) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (c.launch(Intent(action))) ToolResult(Status.SUCCESS, "${args["section"] ?: "Settings"} settings khul gayi")
        else ToolResult(Status.FAILED, "Settings open nahi ho payi")
    }
}

/** Android 10+ blocks apps from toggling Wi-Fi/Bluetooth directly; be honest and offer settings. */
class DirectToggleTool(private val c: Context) : Tool {
    override val name = "toggle_connectivity"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val what = args["what"] ?: "wifi"
        c.launch(Intent(if (what == "bluetooth") Settings.ACTION_BLUETOOTH_SETTINGS else Settings.ACTION_WIFI_SETTINGS))
        return ToolResult(Status.ANDROID_RESTRICTION, "$what direct on/off Android allow nahi karta, isliye settings khol di hain")
    }
}

class WebSearchTool(private val c: Context) : Tool {
    override val name = "search_web"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val q = args["query"] ?: return ToolResult(Status.FAILED, "Kya search karoon?")
        val ok = c.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return if (ok) ToolResult(Status.SUCCESS, "'$q' browser mein search ke liye khol diya")
        else ToolResult(Status.FAILED, "Browser open nahi hua")
    }
}
