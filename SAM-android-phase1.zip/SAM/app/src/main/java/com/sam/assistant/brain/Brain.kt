package com.sam.assistant.brain

import com.sam.assistant.core.*

data class Plan(val calls: List<ToolCall>, val directReply: String? = null, val english: Boolean = false)

/** Swap this for an LLM adapter (via your secure backend) without touching UI or tools. */
interface Brain {
    fun plan(text: String): Plan
    fun summarize(plan: Plan, results: List<Pair<ToolCall, ToolResult>>): String
}

/** Offline Hinglish/English rule-based planner. Handles multi-step commands. */
class RuleBasedBrain : Brain {
    private val english = Regex("^(what|how|open|set|turn|tell|battery|time|call|search|start)\\b")

    override fun plan(text: String): Plan {
        val t = text.lowercase().replace(Regex("^(hey )?sam[, ]*"), "").trim()
        val eng = english.containsMatchIn(t) && !t.contains("karo") && !t.contains("kholo")
        if (t.isBlank()) return Plan(emptyList(), if (eng) "Yes Sir?" else "Ji Sir?", eng)
        val calls = t.split(Regex("\\s*(,|\\baur\\b|\\bphir\\b|\\band then\\b|\\band\\b)\\s*"))
            .filter { it.isNotBlank() }.flatMap { parse(it.trim()) }
        if (calls.isEmpty()) return Plan(emptyList(),
            if (eng) "Sir, I can't do that yet. Needs the AI model connected." else
            "Sir, ye main abhi samajh nahi paya. Is type ki baat ke liye AI model connect karna hoga.", eng)
        return Plan(calls, null, eng)
    }

    private fun parse(s: String): List<ToolCall> {
        val out = mutableListOf<ToolCall>()
        if (Regex("battery").containsMatchIn(s)) out += ToolCall("get_battery_status")
        else if (Regex("kitne baje|time kya|what time|samay").containsMatchIn(s)) out += ToolCall("get_time")
        else if (Regex("device|phone model|android version").containsMatchIn(s)) out += ToolCall("get_device_info")
        else if (s.contains("timer")) {
            val n = Regex("(\\d+)").find(s)?.value?.toIntOrNull()
            val sec = when {
                n == null -> null
                Regex("second|sec").containsMatchIn(s) -> n
                Regex("hour|ghant").containsMatchIn(s) -> n * 3600
                else -> n * 60
            }
            out += ToolCall("set_timer", if (sec != null) mapOf("seconds" to "$sec") else emptyMap())
        } else if (s.contains("alarm")) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(s)
            var h = m?.groupValues?.get(1)?.toIntOrNull()
            if (h != null && h < 12 && Regex("shaam|raat|evening|night|\\bpm\\b").containsMatchIn(s)) h += 12
            val min = m?.groupValues?.get(2)?.ifBlank { "0" } ?: "0"
            out += ToolCall("set_alarm", if (h != null) mapOf("hour" to "$h", "minute" to min) else emptyMap())
        } else if (Regex("wi-?fi|bluetooth").containsMatchIn(s)) {
            val w = if (s.contains("bluetooth")) "bluetooth" else "wifi"
            out += if (s.contains("setting")) ToolCall("open_settings", mapOf("section" to w))
                   else ToolCall("toggle_connectivity", mapOf("what" to w))
        } else if (s.contains("setting")) {
            val sec = when {
                s.contains("display") || s.contains("brightness") -> "display"
                s.contains("sound") || s.contains("volume") -> "sound"
                else -> "main"
            }
            out += ToolCall("open_settings", mapOf("section" to sec))
        } else if (Regex("search|dhundo|khojo").containsMatchIn(s)) {
            out += ToolCall("search_web", mapOf("query" to s.replace(Regex("\\b(search|karo|karna|dhundo|khojo|for|google)\\b"), "").trim()))
        } else if (Regex("kholo|khol do|open|start").containsMatchIn(s)) {
            val app = s.replace(Regex("\\b(kholo|khol|do|open|start|karo|app|please)\\b"), "").trim()
            if (app.isNotBlank()) out += ToolCall("open_app", mapOf("app" to app))
        }
        return out
    }

    override fun summarize(plan: Plan, results: List<Pair<ToolCall, ToolResult>>): String {
        val allOk = results.all { it.second.status == Status.SUCCESS }
        if (results.size == 1) return results[0].second.message + if (allOk) ", Sir." else "."
        val sb = StringBuilder(if (allOk) "Done Sir.\n" else "Sir, kuch kaam ho gaye, kuch nahi:\n")
        results.forEach { sb.append(if (it.second.status == Status.SUCCESS) "✓ " else "✗ ").append(it.second.message).append('\n') }
        return sb.toString().trim()
    }
}
