package com.sam.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sam.assistant.ui.SamState
import com.sam.assistant.ui.SamViewModel

class MainActivity : ComponentActivity() {
    private val vm: SamViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { SamScreen(vm) } }
    }
}

@Composable
fun SamScreen(vm: SamViewModel) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.listen() else vm.permissionDenied()
    }
    fun mic() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.listen()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05070F), Color(0xFF0B1330))))
        .systemBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("SAM", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 8.sp)
        Text(vm.state.name, fontSize = 12.sp, color = Color(0xFF6FA8FF))
        Spacer(Modifier.height(12.dp))
        Orb(vm.state)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(vm.messages) { m ->
                Box(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, modifier = Modifier.clip(RoundedCornerShape(16.dp))
                        .background(if (m.fromUser) Color(0xFF2A4BFF) else Color(0xFF1A2342)).padding(12.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f),
                placeholder = { Text("Sam se kuch kahein…") }, singleLine = true)
            TextButton({ if (input.isNotBlank()) { vm.submit(input); input = "" } }) { Text("Send") }
            FilledIconButton({ mic() }, Modifier.size(52.dp)) { Text("🎙") }
        }
    }
}

@Composable
fun Orb(state: SamState) {
    val t = rememberInfiniteTransition(label = "orb")
    val speed = when (state) { SamState.LISTENING -> 500; SamState.THINKING, SamState.EXECUTING -> 900; SamState.SPEAKING -> 350; else -> 2200 }
    val s by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(speed, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val c = if (state == SamState.ERROR) Color(0xFFFF4D4D) else Color(0xFF4D7CFF)
    Box(Modifier.size(120.dp).scale(s).clip(CircleShape)
        .background(Brush.radialGradient(listOf(Color.White.copy(0.9f), c, Color(0xFF0B1330)))))
}
