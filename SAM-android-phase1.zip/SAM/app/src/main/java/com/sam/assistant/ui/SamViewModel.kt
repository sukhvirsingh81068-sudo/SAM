package com.sam.assistant.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sam.assistant.brain.Brain
import com.sam.assistant.brain.RuleBasedBrain
import com.sam.assistant.core.ToolRegistry
import com.sam.assistant.tools.*
import com.sam.assistant.voice.VoiceEngine
import kotlinx.coroutines.launch

enum class SamState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, ERROR }
data class Msg(val fromUser: Boolean, val text: String)

class SamViewModel(app: Application) : AndroidViewModel(app) {
    val messages = mutableStateListOf(Msg(false, "Ji Sir? Mic dabayein ya type karein."))
    var state by mutableStateOf(SamState.IDLE); private set
    private val brain: Brain = RuleBasedBrain()
    private val registry = ToolRegistry(listOf(OpenAppTool(app), SetTimerTool(app), SetAlarmTool(app),
        BatteryTool(app), TimeTool(), DeviceInfoTool(), OpenSettingsTool(app), DirectToggleTool(app), WebSearchTool(app)))
    private val voice = VoiceEngine(app, { submit(it) },
        { reply(it, false, SamState.ERROR) }, { state = SamState.IDLE })

    fun listen() { voice.stop(); state = SamState.LISTENING; voice.startListening() }
    fun permissionDenied() = reply("Sir, mic permission ke bina main sun nahi sakta. Aap type kar sakte hain.", false, SamState.ERROR)

    fun submit(text: String) {
        messages += Msg(true, text); state = SamState.THINKING
        viewModelScope.launch {
            val plan = brain.plan(text)
            if (plan.calls.isEmpty()) { reply(plan.directReply ?: "", plan.english); return@launch }
            state = SamState.EXECUTING
            val results = plan.calls.map { it to registry.run(it) } // later steps continue even if one fails
            reply(brain.summarize(plan, results), plan.english)
        }
    }

    private fun reply(t: String, english: Boolean, s: SamState = SamState.SPEAKING) {
        messages += Msg(false, t); state = s
        if (s == SamState.SPEAKING) voice.speak(t, english)
    }
    override fun onCleared() { voice.release() }
}
